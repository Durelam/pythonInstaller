#!/bin/python3

# ---added by_me------------------------------------------------------
#    prevents the creation of the bytecode cache
#
import sys
sys.dont_write_bytecode = True
# --------------------------------------------------------------------

from src.exploit import exploit
from src.common import from_bytes, to_bytes
from src.config import Config
from src.device_m2 import Device
from src.logger import log

import argparse
import os

DEFAULT_CONFIG = "default_config.json5"
PAYLOAD_DIR = "payloads/"
DEFAULT_PAYLOAD = "generic_dump_payload.bin"
DEFAULT_DA_ADDRESS = 0x200D00

# ----------------------------------------------------------------------------------------------------------
def main():
      print("Test ok")
# ----------------------------------------------------------------------------------------------------------
if __name__ == "__main__":
    main()
# ----------------------------------------------------------------------------------------------------------