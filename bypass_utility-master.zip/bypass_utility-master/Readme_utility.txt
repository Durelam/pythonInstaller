# Bypass utility
Small utility to disable bootrom protection(sla and daa)

## Payloads
https://github.com/MTK-bypass/exploits_collection

## Usage on Windows
Skip steps 1-5 after first usage

1. Install [python](https://www.python.org/downloads)(select "Add Python X.X to PATH")

2. Install [libusb-win32](https://sourceforge.net/projects/libusb-win32/files/libusb-win32-releases/1.2.6.0/libusb-win32-devel-filter-1.2.6.0.exe/download)

3. Lunch filter wizard, click next

4. Connect powered off phone with volume+ button, you should see new serial device in the list. Select it and click install

5. Install pyusb, pyserial, json5 with command:
   pip install pyusb pyserial json5

6. Run this command and connect your powered off phone with volume+ button, you should get "Protection disabled" at the end
   python main.py

7. After that, without disconnecting phone, run SP Flash Tool

## Credits
- [@chaosmaster](https://github.com/chaosmaster)
- [@xyzz](https://github.com/xyzz)